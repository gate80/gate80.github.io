<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<!--
  Powered by Gate5 engine

  Copyright (c) 2008-2009 Sergey I. Sharybin <g.ulairi@gmail.com>

  This program can be distributed under the terms of GNU GPL.
-->

<html>
  <head>
    <title>GATE</title>
<link rel="stylesheet" type="text/css" href="/gate/styles/content.css">
<link rel="stylesheet" type="text/css" href="/gate/styles/pages.css">
<meta http-equiv="content-language" content="ru">
<meta name="url" content="https://school9.perm.ru/gate/">
<meta name="keywords" content="school9 sch9 gateway gate tester webtester">
<meta name="description" content="OnLine testing system">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="robots" content="all">
<link rel="icon" href="/gate/pics/favicon.ico" type="image/x-icon">
<link rel="SHORTCUT ICON" href="/gate/pics/favicon.ico">
<script language="JavaScript" type="text/javascript">
  var http_host = "https://school9.perm.ru";
  var document_root = "https://school9.perm.ru/gate";
  var engine = "GECKO";
  var isGecko = true;
  var isMSIE = false;
  var force_url = '';
</script>
<script language="JavaScript" type="text/JavaScript" src="/gate/scripts/core.js"></script>
<script language="JavaScript" type="text/JavaScript" src="/gate/scripts/content.js"></script>
<script language="JavaScript" type="text/JavaScript" src="/gate/scripts/ipc.js"></script>
    <script language="JavaScript" type="text/javascript">
      function body_onmousemove (event) {
        if (core_StoreMousePos (event)) return false;
        return true;
      }
      function body_onload (event) {
        if (getElementById ("login").focus ()) return false;
        return true;
      }
    </script>
  </head>
  <body onmousemove="if (!body_onmousemove (event)) return false;" onload="if (!body_onload (event)) return false;" id="content">
    <table width="100%">
      <tr>
        <td id="leftCatchword" valign="top">
          <table>
            <tr>
              <td>
                <div id="logo">
                  <img src="/gate/pics/wt_l.gif" alt="logo" onclick="nav ('/gate');">
                </div>
                <div id="nav">
<div class="menu">
  <div class="cpt">Навигация</div>
  <div class="body">
    <ul>
      <li><a href="/gate/">Заглавная страница</a></li>
      <li><a href="/gate/tester/?redirect=%2Fgate%2Farticles%2Ftrainings%2Fenter.php">Олимпиады</a></li>
      <li><a href="/gate/articles/trainings">Тренировки</a></li>
    </ul>
  </div>
</div>
<div class="menu" style="padding-top: 8px;">
  <div class="cpt">Wiki</div>
  <div class="body">
    <ul>
      <li><a href="/gate/articles/news">Новости</a></li>
      <li><a href="/gate/articles/FAQ">ЧаВо</a></li>
      <li><a href="/gate/articles/nicety">Тонкости работы в системе</a></li>
      <li><a href="/gate/articles/rules">Правила</a></li>
      <li><a href="/gate/articles/about">О проекте</a></li>
      <li><a href="/gate/articles/contacts">Наши контакты</a></li>
    </ul>
  </div>
</div>
<div class="menu" style="padding-top: 8px;">
  <div class="cpt">Ресурсы</div>
  <div class="body">
    <ul>
      <li><a href="/gate/resources/downloads">Downloads</a></li>
    </ul>
  </div>
</div>
                </div>
                <img src="/gate/pics/clear.gif" width="145" height="1" alt="">
              </td>
            </tr>
          </table>
        </td>
        <td valign="top" style="width: 100%;">
          <table id="container">
            <tr><td style="padding: 2px 0;"><div class="transp_menu"><table class="hor_menu"><tr><td align="right">
  <table class="cntsmall"><tr>
    <td class="first"><span class="imghref" style="background: url(/gate/pics/key.gif) no-repeat left center;"><a href="/gate/login?redirect=%2Fgate%2Farticles%2Ftrainings%2Fenter.php">Представиться системе / Зарегистрироваться</a></span></td>
    <td class="sep">::</td>
    <td><a href="/gate/admin/?redirect=%2Fgate%2Farticles%2Ftrainings%2Fenter.php">Административный интерфейс</a></td>
  </tr></table>
</td></tr></table>
</div>
</td></tr>
            <tr>
              <td style="padding-left: 8px;">
                <table class="frame">
  <tr class="h">
    <td class="sp"><img src="/gate/pics/clear.gif" class="sep16" alt=""></td>
    <td class="tc"><div><a href="/gate/login/?redirect=%2Fgate%2Farticles%2Ftrainings%2Fenter.php">Системная страница</a></div></td>
    <td class="sp" style="width: 100%"><img src="/gate/pics/clear.gif"></td>
  </tr>
  <tr>
    <td colspan="3"><div class="frame_cnt"><div id="navigator">Вход в систему</div>
<form action=".?redirect=%2Fgate%2Farticles%2Ftrainings%2Fenter.php" method="POST">
  <div class="form" style="width: 460px; margin-left: 40px;">
    <div class="content">
      <div id="navigator">Введите ваше имя пользователя и пароль</div>
      <div class="contentSub"><span class="arr">Чтобы представиться системе &laquo;<a href="/gate/articles/about">GATE</a>&raquo;</span></div>
      <table width="100%">
        <tr>
          <td>
            <table width="100%" style="margin-left: 64px;">
              <tr>
                <td width="60">Ваш логин:</td>
                <td><input type="text" class="txt" value="" name="login" id="login" size="40"></td>
              </tr>
              <tr>
                <td width="60" style="padding-top: 4px;">Пароль:</td>
                <td style="padding-top: 4px;"><input type="password" class="passwd" name="passwd" size="40"></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td colspan="2" style="padding-left: 32px;">
            <div style="margin: 6px 0;">Если у Вас нет логина, то вы можете <a href="/gate/login/registration/?redirect=%2Fgate%2Flogin%2F%3Fredirect%3D%252Fgate%252Farticles%252Ftrainings%252Fenter.php">зарегистрироваться</a>.</div>
            <div style="margin: 6px 0;">Если Вы забыли свой пароль, то мы можем <a href="/gate/login/restore">выслать новый пароль</a>.</div>
          </td>
        </tr>
        <tr>
          <td align="center" colspan="2" style="padding-top: 4px;">
            <button type="button" class="submitBtn" onclick="nav ('/gate/articles/trainings/enter.php');">Назад</button>
            <button class="submitBtn" type="submit"><b>Представиться</b></button>
          </td>
        </tr>
      </table>
    </div>
    </div>
</form>
</div></td>
  </tr>
</table>

              </td>
            </tr>
          </table>
          <img src="/gate/pics/clear.gif" width="620" height="1" alt="">
        </td>
      </tr>
      <tr>
        <td colspan="2"><div id="footer" style="padding-bottom: 4px;">
  <!--<center>
    <small>
      <span class="contentSub">[DEBUG] Страница была сгенерирована за 0.017052888870239сек. Использовано запросов: 17</span>
    </small>
  </center>-->
  <div id="hr" style="margin: 6px 0 1px 0;"></div>
  <table width="100%" class="small">
    <tr>
      <td width="50%">Powered by Gate5 Engine (c) 2006-2010 nazgul</td>
      <td align="right">Все права защищены (с) 2008 sch9 team</td>
    </tr>
  </table>
</div>

</td>
      </tr>
    </table>
  </body>
</html>
